package com.hiker.editor.editor.jsc.javascript;

import android.content.Context;

import com.hiker.editor.R;

public class Colors {
    //变量颜色
    static public int variable;
    //修饰符颜色
    static public int modifier;
    //关键字颜色
    static public int keyword;
    //数字颜色
    static public int number;
    //字符串颜色
    static public int string;
    //符号颜色
    static public int symbol;
    //运算符颜色
    static public int operator;
    //方法名颜色
    static public int method;
    //注释颜色
    static public int comment;
    //错误颜色
    static public int error;
    //其他颜色
    static public int other;

    public static void init(Context context) {
        variable = context.getResources().getColor(R.color.code_variable);
        modifier = context.getResources().getColor(R.color.code_modifier);
        keyword = context.getResources().getColor(R.color.code_keyword);
        number = context.getResources().getColor(R.color.code_number);
        string = context.getResources().getColor(R.color.code_string);
        symbol = context.getResources().getColor(R.color.code_symbol);
        operator = context.getResources().getColor(R.color.code_operator);
        method = context.getResources().getColor(R.color.code_method);
        comment = context.getResources().getColor(R.color.code_comment);
        error = context.getResources().getColor(R.color.code_error);
        other = context.getResources().getColor(R.color.code_other);
    }

}
