/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package com.hiker.editor.editor.jsc.javascript;

import java.io.IOException;
import java.io.Reader;
import java.math.BigInteger;


public class TokenStream {
    /*
     * For chars - because we need something out-of-range
     * to check.  (And checking EOF by exception is annoying.)
     * Note distinction from EOF token type!
     */
    private static final int EOF_CHAR = -1;
    private static final int VERSION_ES6 = 200;
    private static final int VERSION_1_7 = 170;
    /*
     * Return value for readDigits() to signal the caller has
     * to return an number format problem.
     */
    private static final int REPORT_NUMBER_FORMAT_ERROR = -2;

    private static final char BYTE_ORDER_MARK = '\uFEFF';
    private static final char NUMERIC_SEPARATOR = '_';
    private static final double NaN = Double.longBitsToDouble(0x7ff8000000000000L);
    private static final String[] JS_KEYWORDS = new String[] {
            "map", "filter", "sort", "Map", "Set", "indexOf", "split", "replace", "join", "length", "unshift", "push",
            "parseInt", "test", "match", "Referer", "User-Agent", "Cookie", "getResCode", "request", "fetch", "parseDom",
            "parseDomForHtml", "parseDomForArray", "MY_URL", "MY_PARAMS", "MY_RULE", "MY_ACCOUNT", "MY_ACCOUNT", "setResult",
            "rule", "lazyRule", "writeFile", "fileExist", "saveImage", "setPageTitle", "getColTypes", "getRuleCount",
            "getLastRules", "refreshPage", "refreshX5WebView", "batchFetch", "setLastChapterRule", "getParam", "log", "col_type",
            "getCryptoJS", "base64Decode", "base64Encode", "escape", "decodeURIComponent", "bookmark", "download", "history",
            "collection", "setting", "onChange", "addListener", "onClose", "onRefresh", "getAppVersion", "exports", "require",
            "toString", "clearVar", "showLoading", "hideLoading", "confirm", "cancel", "setItem", "getItem", "clearItem",
            "saveFile", "readFile", "canBack", "MOBILE_UA", "PC_UA", "getCode", "pdfa", "pdfh", "refresh", "listen",
            "fy_bridge_app", "parsePaste", "deleteFile", "getVar", "putVar", "blockRules", "getPastes", "sharePaste",
            "evalPrivateJS", "getPrivateJS", "isLogin", "md5", "subtitle", "requireCache", "fetchCache", "hexToBytes",
            "cacheM3u8", "batchCacheM3u8", "danmu", "setPagePicUrl", "post", "postRequest", "buildUrl", "deleteCache",
            "putMyVar", "getMyVar", "initConfig", "config", "clearMyVar", "getUrl", "RegExp", "downloadFile", "loadJavaClass",
            "requireDownload", "MY_PAGE", "batchExecute", "updateItem", "addItemAfter", "addItemBefore", "deleteItem", "toast",
            "getPath", "audioUrls", "MY_HOME", "getIP", "xpath", "xpathArray", "decode", "encode", "rsaEncrypt", "rsaDecrypt",
            "getHome"
    };

    public TokenStream( Reader sourceReader, String sourceString, int lineno) {

        this.lineno = lineno;
        if (sourceReader != null) {
            if (sourceString != null) Kit.codeBug();
            this.sourceReader = sourceReader;
            this.sourceBuffer = new char[512];
            this.sourceEnd = 0;
        } else {
            if (sourceString == null) Kit.codeBug();
            this.sourceString = sourceString;

            this.sourceEnd = sourceString.length();
        }
        this.sourceCursor = this.cursor = 0;
    }

    static boolean isKeyword(String s, int version, boolean isStrict) {
        return Token.EOF != stringToKeyword(s, version, isStrict);
    }

    private static int stringToKeyword(String name, int version, boolean isStrict) {
        if (version < VERSION_ES6) {
            return stringToKeywordForJS(name);
        }
        return stringToKeywordForES(name, isStrict);
    }

    /** JavaScript 1.8 and earlier */
    private static int stringToKeywordForJS(String name) {
        // The following assumes that Token.EOF == 0
        final int Id_break = Token.BREAK,
                Id_case = Token.CASE,
                Id_continue = Token.CONTINUE,
                Id_default = Token.DEFAULT,
                Id_delete = Token.DELPROP,
                Id_do = Token.DO,
                Id_else = Token.ELSE,
                Id_export = Token.RESERVED,
                Id_false = Token.FALSE,
                Id_for = Token.FOR,
                Id_function = Token.FUNCTION,
                Id_if = Token.IF,
                Id_in = Token.IN,
                Id_of = Token.OF,
                Id_let = Token.LET, // reserved ES5 strict
                Id_new = Token.NEW,
                Id_null = Token.NULL,
                Id_return = Token.RETURN,
                Id_switch = Token.SWITCH,
                Id_this = Token.THIS,
                Id_true = Token.TRUE,
                Id_typeof = Token.TYPEOF,
                Id_var = Token.VAR,
                Id_void = Token.VOID,
                Id_while = Token.WHILE,
                Id_with = Token.WITH,
                Id_yield = Token.YIELD, // reserved ES5 strict

                // the following are #ifdef RESERVE_JAVA_KEYWORDS in jsscan.c
                Id_abstract = Token.RESERVED, // ES3 only
                Id_boolean = Token.RESERVED, // ES3 only
                Id_byte = Token.RESERVED, // ES3 only
                Id_catch = Token.CATCH,
                Id_char = Token.RESERVED, // ES3 only
                Id_class = Token.RESERVED,
                Id_const = Token.CONST, // reserved
                Id_debugger = Token.DEBUGGER,
                Id_double = Token.RESERVED, // ES3 only
                Id_enum = Token.RESERVED,
                Id_extends = Token.RESERVED,
                Id_final = Token.RESERVED, // ES3 only
                Id_finally = Token.FINALLY,
                Id_float = Token.RESERVED, // ES3 only
                Id_goto = Token.RESERVED, // ES3 only
                Id_implements = Token.RESERVED, // ES3, ES5 strict
                Id_import = Token.RESERVED,
                Id_instanceof = Token.INSTANCEOF,
                Id_int = Token.RESERVED, // ES3
                Id_interface = Token.RESERVED, // ES3, ES5 strict
                Id_long = Token.RESERVED, // ES3 only
                Id_native = Token.RESERVED, // ES3 only
                Id_package = Token.RESERVED, // ES3, ES5 strict
                Id_private = Token.RESERVED, // ES3, ES5 strict
                Id_protected = Token.RESERVED, // ES3, ES5 strict
                Id_public = Token.RESERVED, // ES3, ES5 strict
                Id_short = Token.RESERVED, // ES3 only
                Id_static = Token.RESERVED, // ES3, ES5 strict
                Id_super = Token.RESERVED,
                Id_synchronized = Token.RESERVED, // ES3 only
                Id_throw = Token.THROW,
                Id_throws = Token.RESERVED, // ES3 only
                Id_transient = Token.RESERVED, // ES3 only
                Id_try = Token.TRY,
                Id_volatile = Token.RESERVED; // ES3 only

        int id;

        switch (name) {
            case "break":
                id = Id_break;
                break;
            case "case":
                id = Id_case;
                break;
            case "continue":
                id = Id_continue;
                break;
            case "default":
                id = Id_default;
                break;
            case "delete":
                id = Id_delete;
                break;
            case "do":
                id = Id_do;
                break;
            case "else":
                id = Id_else;
                break;
            case "export":
                id = Id_export;
                break;
            case "false":
                id = Id_false;
                break;
            case "for":
                id = Id_for;
                break;
            case "function":
                id = Id_function;
                break;
            case "if":
                id = Id_if;
                break;
            case "in":
                id = Id_in;
                break;
            case "of":
                id = Id_of;
                break;
            case "let":
                id = Id_let;
                break;
            case "new":
                id = Id_new;
                break;
            case "null":
                id = Id_null;
                break;
            case "return":
                id = Id_return;
                break;
            case "switch":
                id = Id_switch;
                break;
            case "this":
                id = Id_this;
                break;
            case "true":
                id = Id_true;
                break;
            case "typeof":
                id = Id_typeof;
                break;
            case "var":
                id = Id_var;
                break;
            case "void":
                id = Id_void;
                break;
            case "while":
                id = Id_while;
                break;
            case "with":
                id = Id_with;
                break;
            case "yield":
                id = Id_yield;
                break;
            case "abstract":
                id = Id_abstract;
                break;
            case "boolean":
                id = Id_boolean;
                break;
            case "byte":
                id = Id_byte;
                break;
            case "catch":
                id = Id_catch;
                break;
            case "char":
                id = Id_char;
                break;
            case "class":
                id = Id_class;
                break;
            case "const":
                id = Id_const;
                break;
            case "debugger":
                id = Id_debugger;
                break;
            case "double":
                id = Id_double;
                break;
            case "enum":
                id = Id_enum;
                break;
            case "extends":
                id = Id_extends;
                break;
            case "final":
                id = Id_final;
                break;
            case "finally":
                id = Id_finally;
                break;
            case "float":
                id = Id_float;
                break;
            case "goto":
                id = Id_goto;
                break;
            case "implements":
                id = Id_implements;
                break;
            case "import":
                id = Id_import;
                break;
            case "instanceof":
                id = Id_instanceof;
                break;
            case "int":
                id = Id_int;
                break;
            case "interface":
                id = Id_interface;
                break;
            case "long":
                id = Id_long;
                break;
            case "native":
                id = Id_native;
                break;
            case "package":
                id = Id_package;
                break;
            case "private":
                id = Id_private;
                break;
            case "protected":
                id = Id_protected;
                break;
            case "public":
                id = Id_public;
                break;
            case "short":
                id = Id_short;
                break;
            case "static":
                id = Id_static;
                break;
            case "super":
                id = Id_super;
                break;
            case "synchronized":
                id = Id_synchronized;
                break;
            case "throw":
                id = Id_throw;
                break;
            case "throws":
                id = Id_throws;
                break;
            case "transient":
                id = Id_transient;
                break;
            case "try":
                id = Id_try;
                break;
            case "volatile":
                id = Id_volatile;
                break;
            default:
                id = 0;
                for (String ss : JS_KEYWORDS) {
                    if (name.equals(ss)) {
                        id = Token.METHOD;
                        break;
                    }
                }
                break;
        }
        if (id == 0) {
            return Token.EOF;
        }
        return id & 0xff;
    }

    /** ECMAScript 6. */
    private static int stringToKeywordForES(String name, boolean isStrict) {
        // The following assumes that Token.EOF == 0
        final int
                // 11.6.2.1 Keywords (ECMAScript2015)
                Id_break = Token.BREAK,
                Id_case = Token.CASE,
                Id_catch = Token.CATCH,
                Id_class = Token.RESERVED,
                Id_const = Token.CONST,
                Id_continue = Token.CONTINUE,
                Id_debugger = Token.DEBUGGER,
                Id_default = Token.DEFAULT,
                Id_delete = Token.DELPROP,
                Id_do = Token.DO,
                Id_else = Token.ELSE,
                Id_export = Token.RESERVED,
                Id_extends = Token.RESERVED,
                Id_finally = Token.FINALLY,
                Id_for = Token.FOR,
                Id_function = Token.FUNCTION,
                Id_if = Token.IF,
                Id_import = Token.RESERVED,
                Id_in = Token.IN,
                Id_of = Token.OF,
                Id_instanceof = Token.INSTANCEOF,
                Id_new = Token.NEW,
                Id_return = Token.RETURN,
                Id_super = Token.RESERVED,
                Id_switch = Token.SWITCH,
                Id_this = Token.THIS,
                Id_throw = Token.THROW,
                Id_try = Token.TRY,
                Id_typeof = Token.TYPEOF,
                Id_var = Token.VAR,
                Id_void = Token.VOID,
                Id_while = Token.WHILE,
                Id_with = Token.WITH,
                Id_yield = Token.YIELD,

                // 11.6.2.2 Future Reserved Words
                Id_await = Token.RESERVED,
                Id_enum = Token.RESERVED,

                // 11.6.2.2 NOTE Strict Future Reserved Words
                Id_implements = Token.RESERVED,
                Id_interface = Token.RESERVED,
                Id_package = Token.RESERVED,
                Id_private = Token.RESERVED,
                Id_protected = Token.RESERVED,
                Id_public = Token.RESERVED,

                // 11.8 Literals
                Id_false = Token.FALSE,
                Id_null = Token.NULL,
                Id_true = Token.TRUE,

                // Non ReservedWord, but Non IdentifierName in strict mode code.
                // 12.1.1 Static Semantics: Early Errors
                Id_let = Token.LET, // TODO : Valid IdentifierName in non-strict mode.
                Id_static = Token.RESERVED;

        int id = 0;
        switch (name) {
            case "break":
                id = Id_break;
                break;
            case "case":
                id = Id_case;
                break;
            case "catch":
                id = Id_catch;
                break;
            case "class":
                id = Id_class;
                break;
            case "const":
                id = Id_const;
                break;
            case "continue":
                id = Id_continue;
                break;
            case "debugger":
                id = Id_debugger;
                break;
            case "default":
                id = Id_default;
                break;
            case "delete":
                id = Id_delete;
                break;
            case "do":
                id = Id_do;
                break;
            case "else":
                id = Id_else;
                break;
            case "export":
                id = Id_export;
                break;
            case "extends":
                id = Id_extends;
                break;
            case "finally":
                id = Id_finally;
                break;
            case "for":
                id = Id_for;
                break;
            case "function":
                id = Id_function;
                break;
            case "if":
                id = Id_if;
                break;
            case "import":
                id = Id_import;
                break;
            case "in":
                id = Id_in;
                break;
            case "of":
                id = Id_of;
                break;
            case "instanceof":
                id = Id_instanceof;
                break;
            case "new":
                id = Id_new;
                break;
            case "return":
                id = Id_return;
                break;
            case "super":
                id = Id_super;
                break;
            case "switch":
                id = Id_switch;
                break;
            case "this":
                id = Id_this;
                break;
            case "throw":
                id = Id_throw;
                break;
            case "try":
                id = Id_try;
                break;
            case "typeof":
                id = Id_typeof;
                break;
            case "var":
                id = Id_var;
                break;
            case "void":
                id = Id_void;
                break;
            case "while":
                id = Id_while;
                break;
            case "with":
                id = Id_with;
                break;
            case "yield":
                id = Id_yield;
                break;
            case "await":
                id = Id_await;
                break;
            case "enum":
                id = Id_enum;
                break;
            case "implements":
                if (isStrict) {
                    id = Id_implements;
                }
                break;
            case "interface":
                if (isStrict) {
                    id = Id_interface;
                }
                break;
            case "package":
                if (isStrict) {
                    id = Id_package;
                }
                break;
            case "private":
                if (isStrict) {
                    id = Id_private;
                }
                break;
            case "protected":
                if (isStrict) {
                    id = Id_protected;
                }
                break;
            case "public":
                if (isStrict) {
                    id = Id_public;
                }
                break;
            case "false":
                id = Id_false;
                break;
            case "null":
                id = Id_null;
                break;
            case "true":
                id = Id_true;
                break;
            case "let":
                id = Id_let;
                break;
            case "static":
                if (isStrict) {
                    id = Id_static;
                }
                break;
            default:
                id = 0;
                for (String ss : JS_KEYWORDS) {
                    if (name.equals(ss)) {
                        id = Token.METHOD;
                        break;
                    }
                }
                break;
        }
        if (id == 0) {
            return Token.EOF;
        }
        return id & 0xff;
    }

    public final int getToken() throws IOException {
        int c;

        for (; ; ) {
            // Eat whitespace, possibly sensitive to newlines.
            for (; ; ) {
                c = getChar();
                if (c == EOF_CHAR) {
                    tokenBeg = cursor - 1;
                    tokenEnd = cursor;
                    return Token.EOF;
                } else if (c == '\n') {
                    dirtyLine = false;
                    tokenBeg = cursor - 1;
                    tokenEnd = cursor;
                    return Token.EOL;
                } else if (!isJSSpace(c)) {
                    if (c != '-') {
                        dirtyLine = true;
                    }
                    break;
                }
            }

            // Assume the token will be 1 char - fixed up below.
            tokenBeg = cursor - 1;
            tokenEnd = cursor;

            if (c == '@') return Token.XMLATTR;

            // identifier/keyword/instanceof?
            // watch out for starting with a <backslash>
            boolean identifierStart;
            boolean isUnicodeEscapeStart = false;
            if (c == '\\') {
                c = getChar();
                if (c == 'u') {
                    identifierStart = true;
                    isUnicodeEscapeStart = true;
                    stringBufferTop = 0;
                } else {
                    identifierStart = false;
                    ungetChar(c);
                    c = '\\';
                }
            } else {
                identifierStart = Character.isJavaIdentifierStart((char) c);
                if (identifierStart) {
                    stringBufferTop = 0;
                    addToString(c);
                }
            }

            if (identifierStart) {
                boolean containsEscape = isUnicodeEscapeStart;
                for (; ; ) {
                    if (isUnicodeEscapeStart) {
                        // strictly speaking we should probably push-back
                        // all the bad characters if the <backslash>uXXXX
                        // sequence is malformed. But since there isn't a
                        // correct context(is there?) for a bad Unicode
                        // escape sequence in an identifier, we can report
                        // an error here.
                        int escapeVal = 0;
                        for (int i = 0; i != 4; ++i) {
                            c = getChar();
                            escapeVal = Kit.xDigitToInt(c, escapeVal);
                            // Next check takes care about c < 0 and bad escape
                            if (escapeVal < 0) {
                                break;
                            }
                        }
                        if (escapeVal < 0) {
                            //parser.addError("msg.invalid.escape");
                            return Token.ERROR;
                        }
                        addToString(escapeVal);
                        isUnicodeEscapeStart = false;
                    } else {
                        c = getChar();
                        if (c == '\\') {
                            c = getChar();
                            if (c == 'u') {
                                isUnicodeEscapeStart = true;
                                containsEscape = true;
                            } else {
                                //parser.addError("msg.illegal.character", c);
                                return Token.ERROR;
                            }
                        } else {
                            if (c == EOF_CHAR
                                    || c == BYTE_ORDER_MARK
                                    || !Character.isJavaIdentifierPart((char) c)) {
                                break;
                            }
                            addToString(c);
                        }
                    }
                }
                ungetChar(c);

                String str = getStringFromBuffer();
                if (!containsEscape) {
                    // OPT we shouldn't have to make a string (object!) to
                    // check if it's a keyword.

                    // Return the corresponding token if it's a keyword
                    int result =
                            stringToKeyword(
                                    str,
                                    200,
                                    true);
                    if (result != Token.EOF) {
                        if ((result == Token.LET || result == Token.YIELD)
                                && 200 < VERSION_1_7) {
                            // LET and YIELD are tokens only in 1.7 and later
                            string = result == Token.LET ? "let" : "yield";
                            result = Token.NAME;
                        }
                        // Save the string in case we need to use in
                        // object literal definitions.
                        this.string = (String) allStrings.intern(str);
                        if (result != Token.RESERVED) {
                            return result;
                        } else if (200 >= VERSION_ES6) {
                            return result;
                        }
                    }
                } else if (isKeyword(
                        str,
                        200,
                        true)) {
                    // If a string contains unicodes, and converted to a keyword,
                    // we convert the last character back to unicode
                    str = convertLastCharToHex(str);
                }
                this.string = (String) allStrings.intern(str);
                return Token.NAME;
            }

            // is it a number?
            if (isDigit(c) || (c == '.' && isDigit(peekChar()))) {
                stringBufferTop = 0;
                int base = 10;
                isHex = isOldOctal = isOctal = isBinary = false;
                boolean es6 = 200 >= VERSION_ES6;

                if (c == '0') {
                    c = getChar();
                    if (c == 'x' || c == 'X') {
                        base = 16;
                        isHex = true;
                        c = getChar();
                    } else if (es6 && (c == 'o' || c == 'O')) {
                        base = 8;
                        isOctal = true;
                        c = getChar();
                    } else if (es6 && (c == 'b' || c == 'B')) {
                        base = 2;
                        isBinary = true;
                        c = getChar();
                    } else if (isDigit(c)) {
                        base = 8;
                        isOldOctal = true;
                    } else {
                        addToString('0');
                    }
                }

                int emptyDetector = stringBufferTop;
                if (base == 10 || base == 16 || (base == 8 && !isOldOctal) || base == 2) {
                    c = readDigits(base, c);
                    if (c == REPORT_NUMBER_FORMAT_ERROR) {
                        //parser.addError("msg.caught.nfe");
                        return Token.ERROR;
                    }
                } else {
                    while (isDigit(c)) {
                        // finally the oldOctal case
                        if (c >= '8') {
                            /*
                             * We permit 08 and 09 as decimal numbers, which
                             * makes our behavior a superset of the ECMA
                             * numeric grammar.  We might not always be so
                             * permissive, so we warn about it.
                             */
                            //parser.addWarning("msg.bad.octal.literal", c == '8' ? "8" : "9");
                            base = 10;

                            c = readDigits(base, c);
                            if (c == REPORT_NUMBER_FORMAT_ERROR) {
                                //parser.addError("msg.caught.nfe");
                                return Token.ERROR;
                            }
                            break;
                        }
                        addToString(c);
                        c = getChar();
                    }
                }
                if (stringBufferTop == emptyDetector && (isBinary || isOctal || isHex)) {
                    //parser.addError("msg.caught.nfe");
                    return Token.ERROR;
                }

                boolean isInteger = true;
                boolean isBigInt = false;

                if (es6 && c == 'n') {
                    isBigInt = true;
                    c = getChar();
                } else if (base == 10 && (c == '.' || c == 'e' || c == 'E')) {
                    isInteger = false;
                    if (c == '.') {
                        isInteger = false;
                        addToString(c);
                        c = getChar();
                        c = readDigits(base, c);
                        if (c == REPORT_NUMBER_FORMAT_ERROR) {
                            //parser.addError("msg.caught.nfe");
                            return Token.ERROR;
                        }
                    }
                    if (c == 'e' || c == 'E') {
                        isInteger = false;
                        addToString(c);
                        c = getChar();
                        if (c == '+' || c == '-') {
                            addToString(c);
                            c = getChar();
                        }
                        if (!isDigit(c)) {
                            ///parser.addError("msg.missing.exponent");
                            return Token.ERROR;
                        }
                        c = readDigits(base, c);
                        if (c == REPORT_NUMBER_FORMAT_ERROR) {
                            //parser.addError("msg.caught.nfe");
                            return Token.ERROR;
                        }
                    }
                }
                ungetChar(c);
                String numString = getStringFromBuffer();
                this.string = numString;

                // try to remove the separator in a fast way
                int pos = numString.indexOf(NUMERIC_SEPARATOR);
                if (pos != -1) {
                    final char[] chars = numString.toCharArray();
                    for (int i = pos + 1; i < chars.length; i++) {
                        if (chars[i] != NUMERIC_SEPARATOR) {
                            chars[pos++] = chars[i];
                        }
                    }
                    numString = new String(chars, 0, pos);
                }

                if (isBigInt) {
                    this.bigInt = new BigInteger(numString, base);
                    return Token.BIGINT;
                }

                double dval;
                if (base == 10 && !isInteger) {
                    try {
                        // Use Java conversion to number from string...
                        dval = Double.parseDouble(numString);
                    } catch (NumberFormatException ex) {
                        //parser.addError("msg.caught.nfe");
                        return Token.ERROR;
                    }
                } else {
                    dval = stringPrefixToNumber(numString, 0, base);
                }

                this.number = dval;
                return Token.NUMBER;
            }

            // is it a string?
            if (c == '"' || c == '\'') {
                // We attempt to accumulate a string the fast way, by
                // building it directly out of the reader.  But if there
                // are any escaped characters in the string, we revert to
                // building it out of a StringBuffer.

                quoteChar = c;
                stringBufferTop = 0;

                c = getCharIgnoreLineEnd(false);
                strLoop:
                while (c != quoteChar) {
                    boolean unterminated = false;
                    if (c == EOF_CHAR) {
                        unterminated = true;
                    } else if (c == '\n') {
                        switch (lineEndChar) {
                            case '\n':
                            case '\r':
                                unterminated = true;
                                break;
                            case 0x2028: // <LS>
                            case 0x2029: // <PS>
                                // Line/Paragraph separators need to be included as is
                                c = lineEndChar;
                                break;
                            default:
                                break;
                        }
                    }

                    if (unterminated) {
                        ungetCharIgnoreLineEnd(c);
                        tokenEnd = cursor;
                        //parser.addError("msg.unterminated.string.lit");
                        return Token.ERROR;
                    }

                    if (c == '\\') {
                        // We've hit an escaped character
                        int escapeVal;

                        c = getChar();
                        switch (c) {
                            case 'b':
                                c = '\b';
                                break;
                            case 'f':
                                c = '\f';
                                break;
                            case 'n':
                                c = '\n';
                                break;
                            case 'r':
                                c = '\r';
                                break;
                            case 't':
                                c = '\t';
                                break;

                                // \v a late addition to the ECMA spec,
                                // it is not in Java, so use 0xb
                            case 'v':
                                c = 0xb;
                                break;

                            case 'u':
                                // Get 4 hex digits; if the u escape is not
                                // followed by 4 hex digits, use 'u' + the
                                // literal character sequence that follows.
                                int escapeStart = stringBufferTop;
                                addToString('u');
                                escapeVal = 0;
                                for (int i = 0; i != 4; ++i) {
                                    c = getChar();
                                    escapeVal = Kit.xDigitToInt(c, escapeVal);
                                    if (escapeVal < 0) {
                                        continue strLoop;
                                    }
                                    addToString(c);
                                }
                                // prepare for replace of stored 'u' sequence
                                // by escape value
                                stringBufferTop = escapeStart;
                                c = escapeVal;
                                break;
                            case 'x':
                                // Get 2 hex digits, defaulting to 'x'+literal
                                // sequence, as above.
                                c = getChar();
                                escapeVal = Kit.xDigitToInt(c, 0);
                                if (escapeVal < 0) {
                                    addToString('x');
                                    continue strLoop;
                                }
                                int c1 = c;
                                c = getChar();
                                escapeVal = Kit.xDigitToInt(c, escapeVal);
                                if (escapeVal < 0) {
                                    addToString('x');
                                    addToString(c1);
                                    continue strLoop;
                                }
                                // got 2 hex digits
                                c = escapeVal;
                                break;

                            case '\n':
                                // Remove line terminator after escape to follow
                                // SpiderMonkey and C/C++
                                c = getChar();
                                continue strLoop;

                            default:
                                if ('0' <= c && c < '8') {
                                    int val = c - '0';
                                    c = getChar();
                                    if ('0' <= c && c < '8') {
                                        val = 8 * val + c - '0';
                                        c = getChar();
                                        if ('0' <= c && c < '8' && val <= 037) {
                                            // c is 3rd char of octal sequence only
                                            // if the resulting val <= 0377
                                            val = 8 * val + c - '0';
                                            c = getChar();
                                        }
                                    }
                                    ungetChar(c);
                                    c = val;
                                }
                        }
                    }
                    addToString(c);
                    c = getChar(false);
                }

                String str = getStringFromBuffer();
                this.string = (String) allStrings.intern(str);
                return Token.STRING;
            }

            switch (c) {
                case ';':
                    return Token.SEMI;
                case '[':
                    return Token.LB;
                case ']':
                    return Token.RB;
                case '{':
                    return Token.LC;
                case '}':
                    return Token.RC;
                case '(':
                    return Token.LP;
                case ')':
                    return Token.RP;
                case ',':
                    return Token.COMMA;
                case '?':
                    return Token.HOOK;
                case ':':
                    if (matchChar(':')) {
                        return Token.COLONCOLON;
                    }
                    return Token.COLON;
                case '.':
                    if (matchChar('.')) {
                        return Token.DOTDOT;
                    } else if (matchChar('(')) {
                        return Token.DOTQUERY;
                    } else {
                        return Token.DOT;
                    }

                case '|':
                    if (matchChar('|')) {
                        return Token.OR;
                    } else if (matchChar('=')) {
                        return Token.ASSIGN_BITOR;
                    } else {
                        return Token.BITOR;
                    }

                case '^':
                    if (matchChar('=')) {
                        return Token.ASSIGN_BITXOR;
                    }
                    return Token.BITXOR;

                case '&':
                    if (matchChar('&')) {
                        return Token.AND;
                    } else if (matchChar('=')) {
                        return Token.ASSIGN_BITAND;
                    } else {
                        return Token.BITAND;
                    }

                case '=':
                    if (matchChar('=')) {
                        if (matchChar('=')) {
                            return Token.SHEQ;
                        }
                        return Token.EQ;
                    } else if (matchChar('>')) {
                        return Token.ARROW;
                    } else {
                        return Token.ASSIGN;
                    }

                case '!':
                    if (matchChar('=')) {
                        if (matchChar('=')) {
                            return Token.SHNE;
                        }
                        return Token.NE;
                    }
                    return Token.NOT;

                case '<':
                    /* NB:treat HTML begin-comment as comment-till-eol */
                    if (matchChar('!')) {
                        if (matchChar('-')) {
                            if (matchChar('-')) {
                                tokenBeg = cursor - 4;
                                skipLine();
                                commentType = Token.CommentType.HTML;
                                return Token.COMMENT;
                            }
                            ungetCharIgnoreLineEnd('-');
                        }
                        ungetCharIgnoreLineEnd('!');
                    }
                    if (matchChar('<')) {
                        if (matchChar('=')) {
                            return Token.ASSIGN_LSH;
                        }
                        return Token.LSH;
                    }
                    if (matchChar('=')) {
                        return Token.LE;
                    }
                    return Token.LT;

                case '>':
                    if (matchChar('>')) {
                        if (matchChar('>')) {
                            if (matchChar('=')) {
                                return Token.ASSIGN_URSH;
                            }
                            return Token.URSH;
                        }
                        if (matchChar('=')) {
                            return Token.ASSIGN_RSH;
                        }
                        return Token.RSH;
                    }
                    if (matchChar('=')) {
                        return Token.GE;
                    }
                    return Token.GT;

                case '*':
                    if (200 >= VERSION_ES6) {
                        if (matchChar('*')) {
                            if (matchChar('=')) {
                                return Token.ASSIGN_EXP;
                            }
                            return Token.EXP;
                        }
                    }
                    if (matchChar('=')) {
                        return Token.ASSIGN_MUL;
                    }
                    return Token.MUL;

                case '/':
                    markCommentStart();
                    // is it a // comment?
                    if (matchChar('/')) {
                        tokenBeg = cursor - 2;
                        skipLine();
                        commentType = Token.CommentType.LINE;
                        return Token.COMMENT;
                    }
                    // is it a /* or /** comment?
                    if (matchChar('*')) {
                        boolean lookForSlash = false;
                        tokenBeg = cursor - 2;
                        if (matchChar('*')) {
                            lookForSlash = true;
                            commentType = Token.CommentType.JSDOC;
                        } else {
                            commentType = Token.CommentType.BLOCK_COMMENT;
                        }
                        for (; ; ) {
                            c = getChar();
                            if (c == EOF_CHAR) {
                                tokenEnd = cursor - 1;
                                //parser.addError("msg.unterminated.comment");
                                return Token.COMMENT;
                            } else if (c == '*') {
                                lookForSlash = true;
                            } else if (c == '/') {
                                if (lookForSlash) {
                                    tokenEnd = cursor;
                                    return Token.COMMENT;
                                }
                            } else {
                                lookForSlash = false;
                                tokenEnd = cursor;
                            }
                        }
                    }

                    if (matchChar('=')) {
                        return Token.ASSIGN_DIV;
                    }
                    return Token.DIV;

                case '%':
                    if (matchChar('=')) {
                        return Token.ASSIGN_MOD;
                    }
                    return Token.MOD;

                case '~':
                    return Token.BITNOT;

                case '+':
                    if (matchChar('=')) {
                        return Token.ASSIGN_ADD;
                    } else if (matchChar('+')) {
                        return Token.INC;
                    } else {
                        return Token.ADD;
                    }

                case '-':
                    if (matchChar('=')) {
                        c = Token.ASSIGN_SUB;
                    } else if (matchChar('-')) {
                        if (!dirtyLine) {
                            // treat HTML end-comment after possible whitespace
                            // after line start as comment-until-eol
                            if (matchChar('>')) {
                                markCommentStart("--");
                                skipLine();
                                commentType = Token.CommentType.HTML;
                                return Token.COMMENT;
                            }
                        }
                        c = Token.DEC;
                    } else {
                        c = Token.SUB;
                    }
                    dirtyLine = true;
                    return c;

                case '`':
                    return Token.TEMPLATE_LITERAL;

                default:
                    //parser.addError("msg.illegal.character", c);
                    return Token.ERROR;
            }
        }
    }

    /*
     * Helper to read the next digits according to the base
     * and ignore the number separator if there is one.
     */
    private int readDigits(int base, int c) throws IOException {
        if (isDigit(base, c)) {
            addToString(c);

            c = getChar();
            if (c == EOF_CHAR) {
                return EOF_CHAR;
            }

            while (true) {
                if (c == NUMERIC_SEPARATOR) {
                    // we do no peek here, we are optimistic for performance
                    // reasons and because peekChar() only does an getChar/ungetChar.
                    c = getChar();
                    // if the line ends after the separator we have
                    // to report this as an error
                    if (c == '\n' || c == EOF_CHAR) {
                        return REPORT_NUMBER_FORMAT_ERROR;
                    }

                    if (!isDigit(base, c)) {
                        // bad luck we have to roll back
                        ungetChar(c);
                        return NUMERIC_SEPARATOR;
                    }
                    addToString(NUMERIC_SEPARATOR);
                } else if (isDigit(base, c)) {
                    addToString(c);
                    c = getChar();
                    if (c == EOF_CHAR) {
                        return EOF_CHAR;
                    }
                } else {
                    return c;
                }
            }
        }
        return c;
    }

    private static boolean isDigit(int base, int c) {
        return (base == 10 && isDigit(c))
                || (base == 16 && isHexDigit(c))
                || (base == 8 && isOctalDigit(c))
                || (base == 2 && isDualDigit(c));
    }

    private static boolean isDualDigit(int c) {
        return '0' == c || c == '1';
    }

    private static boolean isOctalDigit(int c) {
        return '0' <= c && c <= '7';
    }

    private static boolean isDigit(int c) {
        return '0' <= c && c <= '9';
    }

    private static boolean isHexDigit(int c) {
        return ('0' <= c && c <= '9') || ('a' <= c && c <= 'f') || ('A' <= c && c <= 'F');
    }

    /* As defined in ECMA.  jsscan.c uses C isspace() (which allows
     * \v, I think.)  note that code in getChar() implicitly accepts
     * '\r' == \u000D as well.
     */
    private static boolean isJSSpace(int c) {
        if (c <= 127) {
            return c == 0x20 || c == 0x9 || c == 0xC || c == 0xB;
        }
        return c == 0xA0
                || c == BYTE_ORDER_MARK
                || Character.getType((char) c) == Character.SPACE_SEPARATOR;
    }

    private static boolean isJSFormatChar(int c) {
        return c > 127 && Character.getType((char) c) == Character.FORMAT;
    }


    private String getStringFromBuffer() {
        tokenEnd = cursor;
        return new String(stringBuffer, 0, stringBufferTop);
    }

    private void addToString(int c) {
        int N = stringBufferTop;
        if (N == stringBuffer.length) {
            char[] tmp = new char[stringBuffer.length * 2];
            System.arraycopy(stringBuffer, 0, tmp, 0, N);
            stringBuffer = tmp;
        }
        stringBuffer[N] = (char) c;
        stringBufferTop = N + 1;
    }

    private void ungetChar(int c) {
        // can not unread past across line boundary
        if (ungetCursor != 0 && ungetBuffer[ungetCursor - 1] == '\n') Kit.codeBug();
        ungetBuffer[ungetCursor++] = c;
        cursor--;
    }

    private boolean matchChar(int test) throws IOException {
        int c = getCharIgnoreLineEnd();
        if (c == test) {
            tokenEnd = cursor;
            return true;
        }
        ungetCharIgnoreLineEnd(c);
        return false;
    }

    private int peekChar() throws IOException {
        int c = getChar();
        ungetChar(c);
        return c;
    }

    private int getChar() throws IOException {
        return getChar(true, false);
    }

    private int getChar(boolean skipFormattingChars) throws IOException {
        return getChar(skipFormattingChars, false);
    }

    private int getChar(boolean skipFormattingChars, boolean ignoreLineEnd) throws IOException {
        if (ungetCursor != 0) {
            cursor++;
            return ungetBuffer[--ungetCursor];
        }

        for (; ; ) {
            int c;
            if (sourceString != null) {
                if (sourceCursor == sourceEnd) {
                    hitEOF = true;
                    return EOF_CHAR;
                }
                cursor++;
                c = sourceString.charAt(sourceCursor++);
            } else {
                if (sourceCursor == sourceEnd) {
                    if (!fillSourceBuffer()) {
                        hitEOF = true;
                        return EOF_CHAR;
                    }
                }
                cursor++;
                c = sourceBuffer[sourceCursor++];
            }

            if (!ignoreLineEnd && lineEndChar >= 0) {
                if (lineEndChar == '\r' && c == '\n') {
                    lineEndChar = '\n';
                    continue;
                }
                lineEndChar = -1;
                lineStart = sourceCursor - 1;
                lineno++;
            }

            if (c <= 127) {
                if (c == '\n' || c == '\r') {
                    lineEndChar = c;
                    c = '\n';
                }
            } else {
                if (c == BYTE_ORDER_MARK) return c; // BOM is considered whitespace
                if (skipFormattingChars && isJSFormatChar(c)) {
                    continue;
                }
                if (isJSLineTerminator(c)) {
                    lineEndChar = c;
                    c = '\n';
                }
            }
            return c;
        }
    }
    public static boolean isJSLineTerminator(int c) {
        // Optimization for faster check for eol character:
        // they do not have 0xDFD0 bits set
        if ((c & 0xDFD0) != 0) {
            return false;
        }
        return c == '\n' || c == '\r' || c == 0x2028 || c == 0x2029;
    }
    private int getCharIgnoreLineEnd() throws IOException {
        return getChar(true, true);
    }

    private int getCharIgnoreLineEnd(boolean skipFormattingChars) throws IOException {
        return getChar(skipFormattingChars, true);
    }

    private void ungetCharIgnoreLineEnd(int c) {
        ungetBuffer[ungetCursor++] = c;
        cursor--;
    }

    private void skipLine() throws IOException {
        // skip to end of line
        int c;
        while ((c = getChar()) != EOF_CHAR && c != '\n') {}
        ungetChar(c);
        tokenEnd = cursor;
    }

    private boolean fillSourceBuffer() throws IOException {
        if (sourceString != null) Kit.codeBug();
        if (sourceEnd == sourceBuffer.length) {
            if (lineStart != 0 && !isMarkingComment()) {
                System.arraycopy(sourceBuffer, lineStart, sourceBuffer, 0, sourceEnd - lineStart);
                sourceEnd -= lineStart;
                sourceCursor -= lineStart;
                lineStart = 0;
            } else {
                char[] tmp = new char[sourceBuffer.length * 2];
                System.arraycopy(sourceBuffer, 0, tmp, 0, sourceEnd);
                sourceBuffer = tmp;
            }
        }
        int n = sourceReader.read(sourceBuffer, sourceEnd, sourceBuffer.length - sourceEnd);
        if (n < 0) {
            return false;
        }
        sourceEnd += n;
        return true;
    }

    /** Return the absolute source offset of the last scanned token. */
    public int getTokenBeg() {
        return tokenBeg;
    }

    /** Return the absolute source end-offset of the last scanned token. */
    public int getTokenEnd() {
        return tokenEnd;
    }

    private void markCommentStart() {
        markCommentStart("");
    }

    private void markCommentStart(String prefix) {
        if (sourceReader != null) {
            commentPrefix = prefix;
            commentCursor = sourceCursor - 1;
        }
    }

    private boolean isMarkingComment() {
        return commentCursor != -1;
    }


    private static String convertLastCharToHex(String str) {
        int lastIndex = str.length() - 1;
        StringBuilder buf = new StringBuilder(str.substring(0, lastIndex));
        buf.append("\\u");
        String hexCode = Integer.toHexString(str.charAt(lastIndex));
        for (int i = 0; i < 4 - hexCode.length(); ++i) {
            buf.append('0');
        }
        buf.append(hexCode);
        return buf.toString();
    }

    static double stringPrefixToNumber(String s, int start, int radix) {
        return stringToNumber(s, start, s.length() - 1, radix, true);
    }

    static double stringToNumber(String s, int start, int end, int radix) {
        return stringToNumber(s, start, end, radix, false);
    }

    /*
     * Helper function for toNumber, parseInt, and TokenStream.getToken.
     */
    private static double stringToNumber(
            String source, int sourceStart, int sourceEnd, int radix, boolean isPrefix) {
        char digitMax = '9';
        char lowerCaseBound = 'a';
        char upperCaseBound = 'A';
        if (radix < 10) {
            digitMax = (char) ('0' + radix - 1);
        }
        if (radix > 10) {
            lowerCaseBound = (char) ('a' + radix - 10);
            upperCaseBound = (char) ('A' + radix - 10);
        }
        int end;
        double sum = 0.0;
        for (end = sourceStart; end <= sourceEnd; end++) {
            char c = source.charAt(end);
            int newDigit;
            if ('0' <= c && c <= digitMax) newDigit = c - '0';
            else if ('a' <= c && c < lowerCaseBound) newDigit = c - 'a' + 10;
            else if ('A' <= c && c < upperCaseBound) newDigit = c - 'A' + 10;
            else if (!isPrefix) return NaN; // isn't a prefix but found unexpected char
            else break; // unexpected char
            sum = sum * radix + newDigit;
        }
        if (sourceStart == end) { // stopped right at the beginning
            return NaN;
        }
        if (sum > 9007199254740991.0) {
            if (radix == 10) {
                /* If we're accumulating a decimal number and the number
                 * is >= 2^53, then the result from the repeated multiply-add
                 * above may be inaccurate.  Call Java to get the correct
                 * answer.
                 */
                try {
                    return Double.parseDouble(source.substring(sourceStart, end));
                } catch (NumberFormatException nfe) {
                    return NaN;
                }
            } else if (radix == 2 || radix == 4 || radix == 8 || radix == 16 || radix == 32) {
                /* The number may also be inaccurate for one of these bases.
                 * This happens if the addition in value*radix + digit causes
                 * a round-down to an even least significant mantissa bit
                 * when the first dropped bit is a one.  If any of the
                 * following digits in the number (which haven't been added
                 * in yet) are nonzero then the correct action would have
                 * been to round up instead of down.  An example of this
                 * occurs when reading the number 0x1000000000000081, which
                 * rounds to 0x1000000000000000 instead of 0x1000000000000100.
                 */
                int bitShiftInChar = 1;
                int digit = 0;

                final int SKIP_LEADING_ZEROS = 0;
                final int FIRST_EXACT_53_BITS = 1;
                final int AFTER_BIT_53 = 2;
                final int ZEROS_AFTER_54 = 3;
                final int MIXED_AFTER_54 = 4;

                int state = SKIP_LEADING_ZEROS;
                int exactBitsLimit = 53;
                double factor = 0.0;
                boolean bit53 = false;
                // bit54 is the 54th bit (the first dropped from the mantissa)
                boolean bit54 = false;
                int pos = sourceStart;

                for (; ; ) {
                    if (bitShiftInChar == 1) {
                        if (pos == end) break;
                        digit = source.charAt(pos++);
                        if ('0' <= digit && digit <= '9') digit -= '0';
                        else if ('a' <= digit && digit <= 'z') digit -= 'a' - 10;
                        else digit -= 'A' - 10;
                        bitShiftInChar = radix;
                    }
                    bitShiftInChar >>= 1;
                    boolean bit = (digit & bitShiftInChar) != 0;

                    switch (state) {
                        case SKIP_LEADING_ZEROS:
                            if (bit) {
                                --exactBitsLimit;
                                sum = 1.0;
                                state = FIRST_EXACT_53_BITS;
                            }
                            break;
                        case FIRST_EXACT_53_BITS:
                            sum *= 2.0;
                            if (bit) sum += 1.0;
                            --exactBitsLimit;
                            if (exactBitsLimit == 0) {
                                bit53 = bit;
                                state = AFTER_BIT_53;
                            }
                            break;
                        case AFTER_BIT_53:
                            bit54 = bit;
                            factor = 2.0;
                            state = ZEROS_AFTER_54;
                            break;
                        case ZEROS_AFTER_54:
                            if (bit) {
                                state = MIXED_AFTER_54;
                            }
                            // fallthrough
                        case MIXED_AFTER_54:
                            factor *= 2;
                            break;
                    }
                }
                switch (state) {
                    case SKIP_LEADING_ZEROS:
                        sum = 0.0;
                        break;
                    case FIRST_EXACT_53_BITS:
                    case AFTER_BIT_53:
                        // do nothing
                        break;
                    case ZEROS_AFTER_54:
                        // x1.1 -> x1 + 1 (round up)
                        // x0.1 -> x0 (round down)
                        if (bit54 & bit53) sum += 1.0;
                        sum *= factor;
                        break;
                    case MIXED_AFTER_54:
                        // x.100...1.. -> x + 1 (round up)
                        // x.0anything -> x (round down)
                        if (bit54) sum += 1.0;
                        sum *= factor;
                        break;
                }
            }
            /* We don't worry about inaccurate numbers for any other base. */
        }
        return sum;
    }
    // stuff other than whitespace since start of line
    private boolean dirtyLine;

    String regExpFlags;

    // Set this to an initial non-null value so that the Parser has
    // something to retrieve even if an error has occurred and no
    // string is found.  Fosters one class of error, but saves lots of
    // code.
    private String string = "";
    private double number;
    private BigInteger bigInt;
    private boolean isBinary;
    private boolean isOldOctal;
    private boolean isOctal;
    private boolean isHex;

    // delimiter for last string literal scanned
    private int quoteChar;

    private char[] stringBuffer = new char[128];
    private int stringBufferTop;
    private ObjToIntMap allStrings = new ObjToIntMap(50);

    // Room to backtrace from to < on failed match of the last - in <!--
    private final int[] ungetBuffer = new int[3];
    private int ungetCursor;

    private boolean hitEOF = false;

    private int lineStart = 0;
    private int lineEndChar = -1;
    int lineno;

    private String sourceString;
    private Reader sourceReader;
    private char[] sourceBuffer;
    private int sourceEnd;

    // sourceCursor is an index into a small buffer that keeps a
    // sliding window of the source stream.
    int sourceCursor;

    // cursor is a monotonically increasing index into the original
    // source stream, tracking exactly how far scanning has progressed.
    // Its value is the index of the next character to be scanned.
    int cursor;

    // Record start and end positions of last scanned token.
    int tokenBeg;
    int tokenEnd;

    // Type of last comment scanned.
    Token.CommentType commentType;

    // for xml tokenizer
    private boolean xmlIsAttribute;
    private boolean xmlIsTagContent;
    private int xmlOpenTagsCount;


    private String commentPrefix = "";
    private int commentCursor = -1;
}
